#ifndef REQUESTDISPATCHERTHREAD_H
#define REQUESTDISPATCHERTHREAD_H

#include <QObject>
#include <QByteArray>
#include <QMap>
#include <QString>
#include <QThread>
#include <QDebug>

#include "responsedispatcherthread.h"
#include "response.h"
#include "abstractbuffer.h"
#include "requestworker.h"

class RequestDispatcherThread : public QThread
{
public:
    RequestDispatcherThread(AbstractBuffer<Request>* requests, AbstractBuffer<Response>* responses, bool m_debug)
        : workers(new QList<RequestWorker*>()),
          requests(requests),
          responses(responses),
          m_debug(m_debug)
    {}


    void run() Q_DECL_OVERRIDE {
        while(true){
            Request r = requests->get();
            RequestWorker* rw = new RequestWorker(r, responses, m_debug);
            //connect(rw, &RequestWorker::finished, rw, &QObject::deleteLater);
            workers->append(rw);
            rw->start();

            if(m_debug)
                qDebug() << "Request send to be handle";

            QList<int> l;
            int j = 0;
            for(auto i = workers->begin(); i != workers->end();){
                if((*i)->isFinished()){
                    delete *i;
                    *i = nullptr;
                    i = workers->erase(i);
                } else {
                   ++i;
                }

            }
/*
            int count = 0;
            for(auto i = l.begin(); i != l.end(); ++i, ++count){
                workers->removeAt((*i) - count);
            }

            workers->erase(
/*
            for(int i = 0; i < workers->size(); ++i){
                if(workers->at(i) == nullptr)

            }

            workers->
            foreach (auto i, workers) {
                if(*i == nullptr)
                    workers->erase(i, i);
            }
*/
        }

    }


private:

    QMap<QString, QWebSocket *> clients;
    QList<RequestWorker*>* workers;
    AbstractBuffer<Request>* requests;
    AbstractBuffer<Response>* responses;

    bool m_debug;


};

#endif // REQUESTDISPATCHERTHREAD_H
